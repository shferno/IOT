package com.example.apptest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Handler;


public class control_activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.control_layout);
        Button forward = findViewById(R.id.Forward);
        Button right = findViewById(R.id.Right);
        Button left = findViewById(R.id.Left);
        Button backward = findViewById(R.id.Backward);
        Button stop = findViewById(R.id.Stop);
        Button follow = findViewById(R.id.AutoFollow);
        Button avoid = findViewById(R.id.AutoAvoid);
        TextView ip = findViewById(R.id.showip);
        TextView port = findViewById(R.id.showport);
//        TextView mConsoleTxt = findViewById(R.id.recv);
        WebView web = findViewById(R.id.Web);

        // get IP addr and port number from first activity input
        Intent intent_ip = getIntent();
        Intent intent_port = getIntent();
        String string_ip = intent_ip.getStringExtra("ip");
        String string_port = intent_port.getStringExtra("port");
        String string_streamurl = "http://".concat(string_ip).concat(":2204");
        int int_port = Integer.parseInt(string_port);
        int listen_port = 9999;
//        ip.setText(string_ip); // show 'string_ip' in 'ip' textview
//        port.setText(string_port);
        System.out.println(string_streamurl);
        web.loadUrl(string_streamurl);
        ServerSocket serverSocket;




        // buttons to send socket control Rasp Car

        forward.setOnClickListener(v -> {
//                System.out.println("onClick");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        System.out.println(string_ip); // test if ip is correct
                        System.out.println(int_port); // test if ip is correct
                        Socket socket = new Socket(string_ip, int_port);
                        OutputStream os = socket.getOutputStream();
                        PrintWriter pw = new PrintWriter(os);
                        pw.write("F");
                        pw.flush();
                        socket.shutdownOutput();
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        });
        right.setOnClickListener(v -> {
            System.out.println("right button is pressed");// send right instruction
            new Thread(() -> {
                try {
                    System.out.println(string_ip); // test if ip is correct
                    System.out.println(int_port); // test if ip is correct
                    Socket socket = new Socket(string_ip, int_port);
                    OutputStream os = socket.getOutputStream();
                    PrintWriter pw = new PrintWriter(os);
                    pw.write("R");
                    pw.flush();
                    socket.shutdownOutput();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        });
        left.setOnClickListener(v -> {
            new Thread(() -> {
                try {
                    System.out.println(string_ip); // test if ip is correct
                    System.out.println(int_port); // test if ip is correct
                    Socket socket = new Socket(string_ip, int_port);
                    OutputStream os = socket.getOutputStream();
                    PrintWriter pw = new PrintWriter(os);
                    pw.write("L");
                    pw.flush();
                    socket.shutdownOutput();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();// send left instruction
        });
        backward.setOnClickListener(v -> {
            new Thread(() -> {
                try {
                    System.out.println(string_ip); // test if ip is correct
                    System.out.println(int_port); // test if ip is correct
                    Socket socket = new Socket(string_ip, int_port);
                    OutputStream os = socket.getOutputStream();
                    PrintWriter pw = new PrintWriter(os);
                    pw.write("B");
                    pw.flush();
                    socket.shutdownOutput();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();// send backward instruction
        });
        avoid.setOnClickListener(v -> {
            new Thread(() -> {
                try {
                    System.out.println(string_ip); // test if ip is correct
                    System.out.println(int_port); // test if ip is correct
                    Socket socket = new Socket(string_ip, int_port);
                    OutputStream os = socket.getOutputStream();
                    PrintWriter pw = new PrintWriter(os);
                    pw.write("O");
                    pw.flush();
                    socket.shutdownOutput();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();// send backward instruction
        });

        follow.setOnClickListener(v -> {
            new Thread(() -> {
                try {
                    System.out.println(string_ip); // test if ip is correct
                    System.out.println(int_port); // test if ip is correct
                    Socket socket = new Socket(string_ip, int_port);
                    OutputStream os = socket.getOutputStream();
                    PrintWriter pw = new PrintWriter(os);
                    pw.write("H");
                    pw.flush();
                    socket.shutdownOutput();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();// send backward instruction
        });

        stop.setOnClickListener(v -> {
            new Thread(() -> {
                try {
                    System.out.println(string_ip); // test if ip is correct
                    System.out.println(int_port); // test if ip is correct
                    Socket socket = new Socket(string_ip, int_port);
                    OutputStream os = socket.getOutputStream();
                    PrintWriter pw = new PrintWriter(os);
                    pw.write("S");
                    pw.flush();
                    socket.shutdownOutput();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();// send backward instruction
        });



    }





}

